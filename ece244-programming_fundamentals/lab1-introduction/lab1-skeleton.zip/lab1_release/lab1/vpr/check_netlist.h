void check_netlist (t_subblock_data *subblock_data_ptr, int *num_driver);
