void count_routing_transistors (int num_switch, float R_minW_nmos,
            float R_minW_pmos);
