boolean try_timing_driven_route (struct s_router_opts router_opts, float
         **net_slack, float **net_delay, t_ivec **clb_opins_used_locally);
